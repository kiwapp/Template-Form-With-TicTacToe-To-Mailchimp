Kiwapp.set({
    appParameters : {
        deviceType : "webbrowser",
        osID : "webbrowser",
        deviceIdentifier : "Aurelien Chrome"
    }
});